global os, liner, final_liner, template, ip

os           = None
liner        = None
final_liner  = None
template     = None
ip = None
