# Chrome-Extractor
Python script that will extract all saved passwords from your google chrome database and save it in chrome.txt
>**Note:** Windows only
